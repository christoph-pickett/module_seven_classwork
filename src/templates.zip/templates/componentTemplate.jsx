import React from "react";

export const ComponentTemplate = () => {
  // STATE / VAR

  // USEEFFECT

  // FUNC

  // RETURN
  return <div>Component Template</div>;
};
